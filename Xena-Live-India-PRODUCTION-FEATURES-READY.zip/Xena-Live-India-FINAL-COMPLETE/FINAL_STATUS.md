# Xena Live India — final package status

This package is the current buildable Android + Node.js source assembled from the Xena Live India project supplied in this conversation.

## Included
- Android app: `com.xenalive.india`
- Firebase `google-services.json` for the configured Firebase Android app
- WebView app shell and server-backed UI
- Login/signup API
- Google/Facebook OAuth server routes
- Rooms, room chat, follow/block/report
- Wallet, coins/diamonds, gifts
- Socket.IO room events and WebRTC signalling
- Google Play Billing verification endpoint
- Node.js server + Docker/Render/Koyeb deployment files
- GitHub Actions APK build with an `Xena-Live-India-debug-APK` artifact

## Important
This is **not** a claim that every production feature in the requested feature list is already implemented. In particular, production-grade PostgreSQL, Firebase Phone/OTP/FCM integration, Agora, agency/host-salary/withdrawal administration, PK/ranking/events, and a complete admin APK require their corresponding backend/services and configuration.

Do not use the debug APK as a Play Store release. A signed release/AAB and production credentials are required for publishing.
