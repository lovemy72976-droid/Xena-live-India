# GitHub mobile upload fix

GitHub's mobile upload page may fail when a ZIP or folder is selected. Do not upload the ZIP as the repository source.

Extract this ZIP first. The repository root must contain:

- `build.gradle`
- `settings.gradle`
- `app/`
- `server/`
- `.github/workflows/build-apk.yml`

After committing the extracted files, open GitHub Actions and run **Build Xena Live India APK**. The run summary should contain the artifact **Xena-Live-India-debug-APK**.
