# Production feature additions

Added backend modules for PostgreSQL, Firebase ID-token verification (Phone/OTP + Google), FCM device registration, private chat, agencies, host salary data, withdrawals, VIP, PK battles, events/rankings, voice seats, Agora token generation, and an Admin panel.

Required server secrets: DATABASE_URL, FIREBASE_SERVICE_ACCOUNT_JSON, AGORA_APP_ID, AGORA_APP_CERTIFICATE, ADMIN_USERNAME, ADMIN_PASSWORD.

Secrets must stay on the server and must not be placed in the APK or public GitHub repository.
