# Xena Live India — GitHub Upload

This archive is already arranged as the repository root.

IMPORTANT: Do NOT upload this ZIP file itself to GitHub.
Extract it first, then upload the extracted files/folders into the repository root.

Required root items include:
- .github/workflows/build-apk.yml
- app/
- server/
- build.gradle
- settings.gradle
- gradle.properties
- google-services.json inside app/

After upload:
1. Open GitHub Actions.
2. Select "Build Xena Live India APK".
3. Run workflow.
4. Enter the deployed server URL, for example https://your-server.example.com (without /app).
5. Download the generated artifact: Xena-Live-India-debug-APK.
