const crypto = require('crypto');
let pgPool = null;
let firebaseAdmin = null;
let adminJwt = null;
let agoraRtc = null;

function makeId(prefix){ return `${prefix}_${crypto.randomBytes(8).toString('hex')}`; }

async function initFeatures({app, io, db, saveDb, auth, findUser, tokenFor, jwtSecret}) {
  if (process.env.DATABASE_URL) {
    const { Pool } = require('pg');
    pgPool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSL === 'false' ? false : { rejectUnauthorized:false }, max: 10 });
    const fs = require('fs'), path = require('path');
    const sql = fs.readFileSync(path.join(__dirname,'..','sql','production_features.sql'),'utf8');
    await pgPool.query(sql);
  }
  if (process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
    try {
      firebaseAdmin = require('firebase-admin');
      if (!firebaseAdmin.apps.length) firebaseAdmin.initializeApp({ credential: firebaseAdmin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON)) });
    } catch(e){ console.error('Firebase Admin init failed:', e.message); }
  }
  if (process.env.AGORA_APP_ID && process.env.AGORA_APP_CERTIFICATE) {
    try { agoraRtc = require('agora-access-token').RtcTokenBuilder; } catch(e){ console.error('Agora package unavailable:', e.message); }
  }

  const requireDb = (req,res,next)=>{ if(!pgPool) return res.status(503).json({error:'PostgreSQL DATABASE_URL is not configured'}); next(); };
  const requireAdmin = (req,res,next)=>{ try { const h=req.headers.authorization||''; if(!h.startsWith('Bearer ')) return res.status(401).json({error:'Admin login required'}); const p=require('jsonwebtoken').verify(h.slice(7), jwtSecret); if(p.role!=='admin') return res.status(403).json({error:'Admin only'}); req.admin=p; next(); } catch { return res.status(401).json({error:'Invalid admin token'}); } };

  app.post('/api/admin/login', async (req,res)=>{
    const {username,password}=req.body||{};
    if(!process.env.ADMIN_USERNAME || !process.env.ADMIN_PASSWORD) return res.status(503).json({error:'Admin credentials are not configured'});
    if(username!==process.env.ADMIN_USERNAME || password!==process.env.ADMIN_PASSWORD) return res.status(401).json({error:'Invalid admin credentials'});
    const jwt=require('jsonwebtoken').sign({id:'admin',role:'admin',username},jwtSecret,{expiresIn:'12h'});
    res.json({token:jwt});
  });

  app.post('/api/auth/firebase', async (req,res)=>{
    if(!firebaseAdmin) return res.status(503).json({error:'Firebase Admin is not configured'});
    try {
      const decoded=await firebaseAdmin.auth().verifyIdToken(String(req.body?.idToken||''));
      let u=db.users.find(x=>x.firebaseUid===decoded.uid || (decoded.phone_number && x.mobile===decoded.phone_number) || (decoded.email && x.email===decoded.email));
      if(!u){
        const base=String(decoded.name||decoded.phone_number||decoded.email||'user').replace(/[^a-zA-Z0-9_]/g,'').slice(0,18)||'user'; let username=base,n=1; while(db.users.some(x=>x.username.toLowerCase()===username.toLowerCase())) username=base+(n++);
        u={id:makeId('u'),mobile:decoded.phone_number||null,username,email:decoded.email||null,passwordHash:null,firebaseUid:decoded.uid,coins:12050,diamonds:560,followers:0,following:0,likes:0,createdAt:Date.now()}; db.users.push(u); saveDb();
      } else { u.firebaseUid=decoded.uid; if(decoded.email)u.email=decoded.email; if(decoded.phone_number)u.mobile=decoded.phone_number; saveDb(); }
      res.json({token:tokenFor(u),user:u});
    } catch(e){ res.status(401).json({error:'Invalid Firebase ID token'}); }
  });

  app.post('/api/devices', auth, requireDb, async (req,res)=>{ const u=findUser(req.user.id); if(!u)return res.status(404).json({error:'User not found'}); const token=String(req.body?.token||''); if(!token)return res.status(400).json({error:'FCM token required'}); await pgPool.query('INSERT INTO device_tokens(user_id,token,platform,created_at) VALUES($1,$2,$3,$4) ON CONFLICT(token) DO UPDATE SET user_id=EXCLUDED.user_id,platform=EXCLUDED.platform,created_at=EXCLUDED.created_at',[u.id,token,req.body.platform||'android',Date.now()]); res.json({ok:true}); });

  app.post('/api/chat/private', auth, requireDb, async (req,res)=>{ const to=String(req.body?.receiverId||''), text=String(req.body?.text||'').trim().slice(0,1000); if(!findUser(to)||!text)return res.status(400).json({error:'Receiver and message required'}); const m={id:makeId('pm'),senderId:req.user.id,receiverId:to,text,createdAt:Date.now()}; await pgPool.query('INSERT INTO private_messages(id,sender_id,receiver_id,text,created_at) VALUES($1,$2,$3,$4,$5)',[m.id,m.senderId,m.receiverId,m.text,m.createdAt]); res.json({message:m}); });
  app.get('/api/chat/private/:userId', auth, requireDb, async (req,res)=>{ const q=await pgPool.query('SELECT id,sender_id AS "senderId",receiver_id AS "receiverId",text,created_at AS "createdAt" FROM private_messages WHERE (sender_id=$1 AND receiver_id=$2) OR (sender_id=$2 AND receiver_id=$1) ORDER BY created_at DESC LIMIT 200',[req.user.id,req.params.userId]); res.json({messages:q.rows.reverse()}); });

  app.post('/api/agencies', auth, requireDb, async(req,res)=>{ const name=String(req.body?.name||'').trim(); if(!name)return res.status(400).json({error:'Agency name required'}); const a={id:makeId('ag'),name,ownerId:req.user.id,commissionPct:Math.min(100,Math.max(0,Number(req.body.commissionPct||10))),createdAt:Date.now()}; await pgPool.query('INSERT INTO agencies(id,name,owner_id,commission_pct,created_at) VALUES($1,$2,$3,$4,$5)',[a.id,a.name,a.ownerId,a.commissionPct,a.createdAt]); await pgPool.query('INSERT INTO agency_members(agency_id,user_id,role,joined_at) VALUES($1,$2,$3,$4)',[a.id,req.user.id,'owner',a.createdAt]); res.json({agency:a}); });
  app.post('/api/agencies/:id/join', auth, requireDb, async(req,res)=>{ await pgPool.query('INSERT INTO agency_members(agency_id,user_id,role,joined_at) VALUES($1,$2,$3,$4) ON CONFLICT DO NOTHING',[req.params.id,req.user.id,'host',Date.now()]); res.json({ok:true}); });
  app.get('/api/agencies/:id', auth, requireDb, async(req,res)=>{ const a=(await pgPool.query('SELECT id,name,owner_id AS "ownerId",commission_pct AS "commissionPct",created_at AS "createdAt" FROM agencies WHERE id=$1',[req.params.id])).rows[0]; if(!a)return res.status(404).json({error:'Agency not found'}); const m=(await pgPool.query('SELECT user_id AS "userId",role,joined_at AS "joinedAt" FROM agency_members WHERE agency_id=$1',[req.params.id])).rows; res.json({agency:a,members:m}); });

  app.post('/api/host/salary/rules', requireAdmin, requireDb, async(req,res)=>{ const r={id:makeId('sal'),agencyId:req.body?.agencyId||null,minDiamonds:Math.max(0,Math.floor(Number(req.body?.minDiamonds||0))),salaryAmount:Math.max(0,Math.floor(Number(req.body?.salaryAmount||0))),createdAt:Date.now()}; await pgPool.query('INSERT INTO host_salary_rules(id,agency_id,min_diamonds,salary_amount,created_at) VALUES($1,$2,$3,$4,$5)',[r.id,r.agencyId,r.minDiamonds,r.salaryAmount,r.createdAt]); res.json({rule:r}); });
  app.get('/api/host/salary/rules', auth, requireDb, async(req,res)=>{ const q=await pgPool.query('SELECT id,agency_id AS "agencyId",min_diamonds AS "minDiamonds",salary_amount AS "salaryAmount",created_at AS "createdAt" FROM host_salary_rules ORDER BY min_diamonds ASC'); res.json({rules:q.rows}); });
  app.post('/api/host/salary/calculate', auth, requireDb, async(req,res)=>{ const diamonds=Math.max(0,Math.floor(Number(req.body?.diamonds||0))); const q=await pgPool.query('SELECT id,agency_id AS "agencyId",min_diamonds AS "minDiamonds",salary_amount AS "salaryAmount" FROM host_salary_rules WHERE min_diamonds <= $1 ORDER BY min_diamonds DESC LIMIT 1',[diamonds]); const rule=q.rows[0]||null; const amount=rule?Number(rule.salaryAmount):0; res.json({diamonds,amount,rule}); });
  app.post('/api/host/salary/payout', requireAdmin, requireDb, async(req,res)=>{ const hostId=String(req.body?.hostId||''), diamonds=Math.max(0,Math.floor(Number(req.body?.diamonds||0))), amount=Math.max(0,Math.floor(Number(req.body?.amount||0))); if(!findUser(hostId))return res.status(404).json({error:'Host not found'}); const p={id:makeId('salary'),hostId,agencyId:req.body?.agencyId||null,period:String(req.body?.period||new Date().toISOString().slice(0,7)),diamonds,amount,status:'pending',createdAt:Date.now()}; await pgPool.query('INSERT INTO salary_payouts(id,host_id,agency_id,period,diamonds,amount,status,created_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8)',[p.id,p.hostId,p.agencyId,p.period,p.diamonds,p.amount,p.status,p.createdAt]); res.json({payout:p}); });
  app.get('/api/host/salary/payouts', auth, requireDb, async(req,res)=>{ const q=await pgPool.query('SELECT id,host_id AS "hostId",agency_id AS "agencyId",period,diamonds,amount,status,created_at AS "createdAt" FROM salary_payouts WHERE host_id=$1 ORDER BY created_at DESC LIMIT 100',[req.user.id]); res.json({payouts:q.rows}); });

  app.post('/api/withdrawals', auth, requireDb, async(req,res)=>{ const amount=Math.floor(Number(req.body?.amount||0)); const method=String(req.body?.method||'upi'); const account=String(req.body?.account||'').trim(); const u=findUser(req.user.id); if(!u||amount<100||!account)return res.status(400).json({error:'Minimum withdrawal is 100 diamonds and account is required'}); if(u.diamonds<amount)return res.status(400).json({error:'Not enough diamonds'}); u.diamonds-=amount; saveDb(); const w={id:makeId('wd'),userId:u.id,amount,method,account,status:'pending',createdAt:Date.now()}; await pgPool.query('INSERT INTO withdrawals(id,user_id,amount,method,account,status,created_at) VALUES($1,$2,$3,$4,$5,$6,$7)',[w.id,w.userId,w.amount,w.method,w.account,w.status,w.createdAt]); res.json({ok:true,withdrawal:w,diamonds:u.diamonds}); });
  app.get('/api/withdrawals',auth,requireDb,async(req,res)=>{ const q=await pgPool.query('SELECT id,user_id AS "userId",amount,method,account,status,created_at AS "createdAt",reviewed_at AS "reviewedAt" FROM withdrawals WHERE user_id=$1 ORDER BY created_at DESC LIMIT 100',[req.user.id]); res.json({withdrawals:q.rows}); });

  app.post('/api/vip',auth,requireDb,async(req,res)=>{ const level=Math.max(1,Math.floor(Number(req.body?.level||1))); const days=Math.max(1,Math.floor(Number(req.body?.days||30))); const expires=Date.now()+days*86400000; await pgPool.query('INSERT INTO vip_memberships(user_id,level,expires_at,updated_at) VALUES($1,$2,$3,$4) ON CONFLICT(user_id) DO UPDATE SET level=EXCLUDED.level,expires_at=EXCLUDED.expires_at,updated_at=EXCLUDED.updated_at',[req.user.id,level,expires,Date.now()]); res.json({ok:true,level,expiresAt:expires}); });
  app.get('/api/vip',auth,requireDb,async(req,res)=>{ const q=await pgPool.query('SELECT level,"expires_at" AS "expiresAt" FROM vip_memberships WHERE user_id=$1',[req.user.id]); res.json({vip:q.rows[0]||null}); });

  app.post('/api/pk/start',auth,requireDb,async(req,res)=>{ const a=String(req.body?.hostA||req.user.id), b=String(req.body?.hostB||''); if(!findUser(a)||!findUser(b)||a===b)return res.status(400).json({error:'Two valid hosts required'}); const p={id:makeId('pk'),roomId:String(req.body?.roomId||''),hostA:a,hostB:b,scoreA:0,scoreB:0,status:'live',startedAt:Date.now()}; await pgPool.query('INSERT INTO pk_battles(id,room_id,host_a,host_b,score_a,score_b,status,started_at) VALUES($1,$2,$3,$4,0,0,$5,$6)',[p.id,p.roomId,p.hostA,p.hostB,p.status,p.startedAt]); res.json({battle:p}); });
  app.post('/api/pk/:id/score',auth,requireDb,async(req,res)=>{ const points=Math.max(0,Math.floor(Number(req.body?.points||0))); const q=await pgPool.query('SELECT * FROM pk_battles WHERE id=$1',[req.params.id]); const p=q.rows[0]; if(!p||p.status!=='live')return res.status(404).json({error:'PK not live'}); const col=p.host_a===req.user.id?'score_a':p.host_b===req.user.id?'score_b':null; if(!col)return res.status(403).json({error:'Not a PK host'}); const r=await pgPool.query(`UPDATE pk_battles SET ${col}=${col}+$1 WHERE id=$2 RETURNING *`,[points,p.id]); res.json({battle:r.rows[0]}); });
  app.post('/api/pk/:id/end',auth,requireDb,async(req,res)=>{ const r=await pgPool.query('UPDATE pk_battles SET status=$1,ended_at=$2 WHERE id=$3 RETURNING *',['ended',Date.now(),req.params.id]); if(!r.rows[0])return res.status(404).json({error:'PK not found'}); res.json({battle:r.rows[0]}); });

  app.post('/api/events',requireAdmin,requireDb,async(req,res)=>{ const e={id:makeId('ev'),title:String(req.body?.title||'Event'),description:String(req.body?.description||''),startsAt:Number(req.body?.startsAt||Date.now()),endsAt:Number(req.body?.endsAt||Date.now()+86400000),active:true,createdAt:Date.now()}; await pgPool.query('INSERT INTO events(id,title,description,starts_at,ends_at,active,created_at) VALUES($1,$2,$3,$4,$5,$6,$7)',[e.id,e.title,e.description,e.startsAt,e.endsAt,e.active,e.createdAt]); res.json({event:e}); });
  app.get('/api/events',auth,requireDb,async(req,res)=>{ const q=await pgPool.query('SELECT id,title,description,starts_at AS "startsAt",ends_at AS "endsAt",active,created_at AS "createdAt" FROM events ORDER BY starts_at DESC LIMIT 100'); res.json({events:q.rows}); });
  app.post('/api/events/:id/score',auth,requireDb,async(req,res)=>{ const score=Math.max(0,Math.floor(Number(req.body?.score||0))); await pgPool.query('INSERT INTO event_scores(event_id,user_id,score) VALUES($1,$2,$3) ON CONFLICT(event_id,user_id) DO UPDATE SET score=event_scores.score+EXCLUDED.score',[req.params.id,req.user.id,score]); res.json({ok:true}); });
  app.get('/api/rankings',auth,requireDb,async(req,res)=>{ const q=await pgPool.query('SELECT user_id AS "userId",SUM(score)::bigint AS score FROM event_scores GROUP BY user_id ORDER BY score DESC LIMIT 100'); res.json({rankings:q.rows}); });

  app.post('/api/rooms/:roomId/seats/:seat/claim',auth,requireDb,async(req,res)=>{ const seat=Math.floor(Number(req.params.seat)); if(seat<1||seat>20)return res.status(400).json({error:'Seat must be 1-20'}); const q=await pgPool.query('SELECT * FROM voice_seats WHERE room_id=$1 AND seat_no=$2',[req.params.roomId,seat]); if(q.rows[0]?.locked || q.rows[0]?.user_id)return res.status(409).json({error:'Seat unavailable'}); await pgPool.query('INSERT INTO voice_seats(room_id,seat_no,user_id,muted,locked,updated_at) VALUES($1,$2,$3,false,false,$4) ON CONFLICT(room_id,seat_no) DO UPDATE SET user_id=EXCLUDED.user_id,updated_at=EXCLUDED.updated_at',[req.params.roomId,seat,req.user.id,Date.now()]); res.json({ok:true,seat,userId:req.user.id}); });
  app.post('/api/rooms/:roomId/seats/:seat/release',auth,requireDb,async(req,res)=>{ await pgPool.query('UPDATE voice_seats SET user_id=NULL,updated_at=$1 WHERE room_id=$2 AND seat_no=$3 AND user_id=$4',[Date.now(),req.params.roomId,Number(req.params.seat),req.user.id]); res.json({ok:true}); });
  app.post('/api/rooms/:roomId/seats/:seat/mute',auth,requireDb,async(req,res)=>{ await pgPool.query('UPDATE voice_seats SET muted=$1,updated_at=$2 WHERE room_id=$3 AND seat_no=$4',[!!req.body?.muted,Date.now(),req.params.roomId,Number(req.params.seat)]); res.json({ok:true}); });
  app.get('/api/rooms/:roomId/seats',auth,requireDb,async(req,res)=>{ const q=await pgPool.query('SELECT seat_no AS "seatNo",user_id AS "userId",muted,locked FROM voice_seats WHERE room_id=$1 ORDER BY seat_no',[req.params.roomId]); res.json({seats:q.rows}); });

  app.get('/api/agora/token',auth,async(req,res)=>{ if(!agoraRtc)return res.status(503).json({error:'Agora is not configured. Set AGORA_APP_ID and AGORA_APP_CERTIFICATE.'}); const channel=String(req.query.channel||''); const uid=Math.floor(Number(req.query.uid||0)); if(!channel)return res.status(400).json({error:'channel required'}); const role=String(req.query.role||'publisher')==='audience'?agoraRtc.Role.SUBSCRIBER:agoraRtc.Role.PUBLISHER; const token=agoraRtc.buildTokenWithUid(process.env.AGORA_APP_ID,process.env.AGORA_APP_CERTIFICATE,channel,uid,role,3600); res.json({appId:process.env.AGORA_APP_ID,token,channel,uid,expiresIn:3600}); });

  app.post('/api/admin/notify',requireAdmin,requireDb,async(req,res)=>{ if(!firebaseAdmin)return res.status(503).json({error:'Firebase Admin is not configured'}); const userId=String(req.body?.userId||''), title=String(req.body?.title||'Xena Live India'), body=String(req.body?.body||''); const q=await pgPool.query('SELECT token FROM device_tokens WHERE user_id=$1',[userId]); const tokens=q.rows.map(x=>x.token); if(!tokens.length)return res.status(404).json({error:'No FCM device token'}); const r=await firebaseAdmin.messaging().sendEachForMulticast({tokens,notification:{title,body}}); res.json({ok:true,successCount:r.successCount,failureCount:r.failureCount}); });
  app.get('/api/admin/stats',requireAdmin,requireDb,async(req,res)=>{ const tables=['withdrawals','agencies','events','pk_battles','private_messages']; const out={}; for(const t of tables) out[t]=(await pgPool.query(`SELECT COUNT(*)::int AS count FROM ${t}`)).rows[0].count; out.users=db.users.length; out.rooms=db.rooms.length; res.json(out); });
  app.get('/api/admin/withdrawals',requireAdmin,requireDb,async(req,res)=>{ const q=await pgPool.query('SELECT * FROM withdrawals ORDER BY created_at DESC LIMIT 200'); res.json({withdrawals:q.rows}); });
  app.post('/api/admin/withdrawals/:id/status',requireAdmin,requireDb,async(req,res)=>{ const status=['approved','rejected','paid'].includes(req.body?.status)?req.body.status:null; if(!status)return res.status(400).json({error:'Invalid status'}); const r=await pgPool.query('UPDATE withdrawals SET status=$1,reviewed_at=$2 WHERE id=$3 RETURNING *',[status,Date.now(),req.params.id]); if(!r.rows[0])return res.status(404).json({error:'Withdrawal not found'}); await pgPool.query('INSERT INTO admin_audit(id,admin_id,action,payload,created_at) VALUES($1,$2,$3,$4,$5)',[makeId('audit'),req.admin.id,'withdrawal_status',JSON.stringify({id:req.params.id,status}),Date.now()]); res.json({withdrawal:r.rows[0]}); });
}

module.exports = { initFeatures };
