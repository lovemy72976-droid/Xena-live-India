package com.xenalive.india;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.PermissionRequest;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.Window;

public class MainActivity extends Activity {
    private WebView webView;
    private BillingManager billingManager;
    private static final int MEDIA_PERMISSION = 1001;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(7, 9, 20));
        window.setNavigationBarColor(Color.rgb(7, 9, 20));

        if (android.os.Build.VERSION.SDK_INT >= 23 &&
                (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
                 checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)) {
            requestPermissions(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO}, MEDIA_PERMISSION);
        }

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(7, 9, 20));
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url){
                if(url.startsWith("https://") && (url.contains("/auth/google") || url.contains("/auth/facebook"))){
                    try{ startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }catch(Exception ignored){}
                    return true;
                }
                if(url.startsWith("xena://oauth")){ handleOAuthCallback(Uri.parse(url)); return true; }
                return false;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setUserAgentString(settings.getUserAgentString() + " XenaLiveIndia/2.0");

        setContentView(webView);
        billingManager = new BillingManager(this, webView);
        webView.addJavascriptInterface(new Object(){ @JavascriptInterface public void openOAuth(String provider){
            String url=BuildConfig.SERVER_URL.replaceAll("/app$", "")+"/auth/"+provider;
            runOnUiThread(()->{ try{ startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }catch(Exception ignored){} });
        } }, "XenaAuth");
        webView.addJavascriptInterface(new Object(){ @JavascriptInterface public void buyCoins(String productId, String authToken){ billingManager.buy(productId, authToken); } }, "XenaBilling");
        billingManager.start();
        webView.loadUrl(BuildConfig.SERVER_URL);
    }

    private void handleOAuthCallback(Uri uri){
        String token=uri.getQueryParameter("token");
        if(token==null||token.isEmpty()) return;
        webView.postDelayed(()->webView.evaluateJavascript("localStorage.setItem('xena_token',"+org.json.JSONObject.quote(token)+"); location.href='"+BuildConfig.SERVER_URL+"';",null),100);
    }

    @Override protected void onNewIntent(Intent intent){ super.onNewIntent(intent); setIntent(intent); if(intent!=null && intent.getData()!=null && "xena".equals(intent.getData().getScheme())) handleOAuthCallback(intent.getData()); }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
