# Xena Live India — production checklist

This package is deployment-ready for testing and contains the Android client plus Node.js real-time server.

Before accepting real users or money, configure:

1. HTTPS hosting.
2. A strong Koyeb Secret named `JWT_SECRET` (32+ characters).
3. Persistent storage/database. The JSON fallback is for testing only. Koyeb documents local storage as ephemeral.
4. TURN credentials for reliable mobile WebRTC.
5. Google OAuth credentials and exact callback URL, if Google login is enabled.
6. Facebook/Meta OAuth credentials and exact callback URL, if Facebook login is enabled.
7. Google Play Billing products plus a Google Play Developer API service account for server-side verification.
8. A release signing key and signed Android App Bundle (AAB).
9. Play Console Data safety, privacy policy, account deletion and other required declarations.
10. Two-device testing of signup/login, live camera/mic, chat, gifts, purchase verification, block/report and account deletion.

No ZIP can safely contain the owner's private OAuth keys, Play service-account key, signing key or database password.
