# Xena Live India — Koyeb deployment

## Fastest deployment
1. Deploy this repository as a **Web Service** using the included root `Dockerfile`.
2. Expose HTTP port **8080** and route `/` to 8080. Koyeb provides `PORT` automatically, but the app also defaults to 8080.
3. The app starts without a manually supplied JWT secret: it creates a random secret in `data/.jwt-secret`. For real production, use a Koyeb Secret named `JWT_SECRET` (32+ characters).
4. Open `/health` and confirm `ok: true`. Open `/app` to use the app.

## Important for real users
The included JSON storage is intentionally a zero-setup fallback for testing. Koyeb local filesystem storage is ephemeral, so user data can be lost when an instance is recreated. For a real launch, attach persistent storage or use Koyeb PostgreSQL and migrate the data layer before taking real payments.

Google/Facebook login and Google Play purchase verification are optional integrations. They require the owner's credentials/service account and cannot be safely embedded in a public ZIP.
