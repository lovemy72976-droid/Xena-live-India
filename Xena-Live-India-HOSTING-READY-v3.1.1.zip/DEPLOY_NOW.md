# Xena Live India — Hosting-Ready v3.1.1

This package is prepared so a Node hosting service can run it from the repository root.

## Start command
`npm start`

## Build command
`npm install --omit=dev --no-audit --no-fund`

## Health check
`/health`

## App URL
`/app`

## Koyeb Docker
The included `Dockerfile` is the simplest deployment method. It installs the server dependencies from `server/package.json` and starts `server.js` on `$PORT`.

## Important production configuration
The basic server can start without extra secrets. For a real public launch, configure:
- `JWT_SECRET` (32+ random characters)
- persistent storage for `DATA_DIR`/`DATA_FILE`, or replace the JSON store with a managed database
- `TURN_URL`, `TURN_USERNAME`, `TURN_CREDENTIAL` for reliable WebRTC across restrictive networks
- Google/Facebook OAuth secrets and redirect URIs if those login buttons are enabled
- `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` and `ANDROID_PACKAGE_NAME` for Play Billing verification

Do not put private keys, service-account JSON, OAuth secrets, or Android signing keys inside the ZIP or Git repository.
