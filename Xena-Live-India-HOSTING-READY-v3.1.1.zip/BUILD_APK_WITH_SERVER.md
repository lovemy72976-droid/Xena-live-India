# Build the Android app after hosting

After the server has a final HTTPS URL, build with:

`./gradlew assembleRelease -PxenaServerUrl=https://YOUR-SERVER/app`

The APK uses that URL for login, live rooms, chat, WebRTC signaling, account deletion, and Play Billing verification.
