# Xena Live India Android Project

**App display name: Xena Live India**

Android Studio project for the Xena Live India frontend.

## Included
Home, party rooms, live voice-room UI, chat UI, friends/followers, wallet, VIP,
games, rewards/events, profile, settings and navigation.

## Important
This is a working Android UI/source project, not a production clone of another app.
Real-time voice audio, PK synchronization, gifts/coin accounting, authentication,
payments and moderation require a backend and appropriate third-party real-time
services. The project intentionally does not contain payment credentials or
server secrets.

## Build
Open this folder in Android Studio and let Gradle sync. Then Run on an Android
device/emulator. For a release APK use Build > Generate App Bundles or APKs.

## Emoji
Quick emoji reactions are included in the live room chat UI: 😀 😂 😍 🔥 ❤️ 👏 🎉 🌹.

## Next version
Added full dedicated Gift Center, Emoji Center, and PK Battle screens with navigation from a room.
These are UI/demo interactions; production gifting, coin accounting, PK synchronization and realtime voice require backend services.
