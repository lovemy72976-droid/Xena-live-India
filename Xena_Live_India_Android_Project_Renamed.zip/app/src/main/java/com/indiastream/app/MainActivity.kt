package com.indiastream.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg=Color(0xFF070914); private val Card=Color(0xFF11152A)
private val Purple=Color(0xFF7A35E8); private val Gold=Color(0xFFFFD34F)

data class Room(val name:String,val users:String,val icon:String)
val rooms=listOf(Room("Music Live Room","1.2K","🎵"),Room("Chill Vibes","864","🌙"),Room("Masti with Friends","2.1K","🎉"),Room("Gaming Zone","965","🎮"))

class MainActivity:ComponentActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b);setContent{IndiaStream()}}
}

@Composable fun IndiaStream(){
 var tab by remember{mutableStateOf("Home")}
 var selectedRoom by remember{mutableStateOf<Room?>(null)}
 var overlay by remember{mutableStateOf("")}
 MaterialTheme(colorScheme=darkColorScheme(primary=Purple,background=Bg,surface=Card)){
  Surface(Modifier.fillMaxSize(),color=Bg){
   Column{
    TopBar()
    Box(Modifier.weight(1f)){ when {
     overlay=="gifts" -> GiftScreen{overlay=""}
     overlay=="emoji" -> EmojiScreen{overlay=""}
     overlay=="pk" -> PKBattleScreen{overlay=""}
     selectedRoom!=null -> RoomScreen(selectedRoom!!, {selectedRoom=null}, {overlay="gifts"}, {overlay="emoji"}, {overlay="pk"})
     tab=="Home" -> Home{selectedRoom=it}
     tab=="Rooms" -> Rooms{selectedRoom=it}
     tab=="Chats" -> Friends()
     tab=="Profile" -> Profile()
     tab=="Wallet" -> Wallet()
     tab=="VIP" -> Vip()
     tab=="Games" -> Games()
     tab=="Rewards" -> Rewards()
     tab=="Settings" -> Settings()
     else -> Home{selectedRoom=it}
    }}
    BottomBar(tab){tab=it}
   }
  }
 }
}

@Composable fun TopBar()=Row(Modifier.fillMaxWidth().padding(18.dp),verticalAlignment=Alignment.CenterVertically, horizontalArrangement=Arrangement.SpaceBetween){
 Text("XENA LIVE INDIA",fontSize=21.sp,fontWeight=FontWeight.Bold)
 Text("🔔",fontSize=20.sp)
}
@Composable fun Home(open:(Room)->Unit){
 LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{Hero()}
  item{QuickGrid()}
  item{Text("Popular Rooms",fontSize=20.sp,fontWeight=FontWeight.Bold)}
  items(rooms){RoomCard(it,open)}
 }
}
@Composable fun Hero()=Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF321064)),shape=RoundedCornerShape(20.dp)){
 Column(Modifier.padding(20.dp)){Text("DAILY REWARDS",color=Color(0xFFD7B3FF),fontSize=12.sp);Text("Connect Without Limits",fontSize=25.sp,fontWeight=FontWeight.Bold);Text("Voice rooms • Games • Friends • Rewards",color=Color.LightGray);Spacer(Modifier.height(12.dp));Button(onClick={},shape=RoundedCornerShape(12.dp)){Text("Claim Rewards")}}
}
@Composable fun QuickGrid(){LazyVerticalGrid(columns=GridCells.Fixed(4),modifier=Modifier.height(105.dp),userScrollEnabled=false,contentPadding=PaddingValues(2.dp)){listOf("🎙️\nRooms","👥\nFriends","🎮\nGames","🪙\nWallet").forEach{item{Card(shape=RoundedCornerShape(14.dp),colors=CardDefaults.cardColors(containerColor=Card)){Box(Modifier.fillMaxSize().padding(8.dp),contentAlignment=Alignment.Center){Text(it,textAlign=androidx.compose.ui.text.style.TextAlign.Center,fontSize=12.sp)}}}}}}
@Composable fun Rooms(open:(Room)->Unit){LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text("Party Rooms",fontSize=25.sp,fontWeight=FontWeight.Bold)};items(rooms){RoomCard(it,open)}}}
@Composable fun RoomCard(r:Room,open:(Room)->Unit)=Card(Modifier.fillMaxWidth().clickable{open(r)},colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(16.dp)){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(48.dp).background(Purple,CircleShape),contentAlignment=Alignment.Center){Text(r.icon,fontSize=22.sp)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(r.name,fontWeight=FontWeight.Bold);Text("🎙️ ${r.users} listeners",color=Color.Gray,fontSize=12.sp)};Text("›",fontSize=28.sp)}}}

@Composable fun RoomScreen(r:Room,back:()->Unit,onGift:()->Unit,onEmoji:()->Unit,onPk:()->Unit){
 LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
  item{Row(verticalAlignment=Alignment.CenterVertically){Text("‹",fontSize=35.sp,modifier=Modifier.clickable{back()});Spacer(Modifier.width(10.dp));Column{Text(r.name,fontSize=21.sp,fontWeight=FontWeight.Bold);Text("${r.users} listeners • LIVE",color=Color(0xFF62E6A5),fontSize=12.sp)}}}
  item{Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF18112C))){Column(Modifier.padding(16.dp)){Text("🎙️ Speakers",fontWeight=FontWeight.Bold);Text("  👤 Aarav     👤 Riya     👤 Neha     👤 Vicky",Modifier.padding(top=14.dp))}}}
  item{Card(colors=CardDefaults.cardColors(containerColor=Card)){Column(Modifier.padding(16.dp)){
   Text("Live Chat",color=Color.Gray)
   Text("Riya: Welcome! 👋");Text("Vicky: Great voice 🎵");Text("Neha sent 🌹 x10")
   Spacer(Modifier.height(10.dp))
   Text("Quick Emojis",color=Color.LightGray,fontSize=12.sp)
   Row(Modifier.fillMaxWidth().padding(top=6.dp),horizontalArrangement=Arrangement.SpaceBetween){
    listOf("😀","😂","😍","🔥","❤️","👏","🎉","🌹").forEach{e->
     Text(e,fontSize=24.sp,modifier=Modifier.clickable{})
    }
   }
  }}}
  item{Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){
    Button(onClick=onGift,modifier=Modifier.weight(1f)){Text("🎁 Gift")}
    Button(onClick=onEmoji,modifier=Modifier.weight(1f)){Text("😀 Emoji")}
    Button(onClick=onPk,modifier=Modifier.weight(1f)){Text("⚔️ PK")}
  }}
 }
}
@Composable fun Friends(){SimpleList("Friends & Followers",listOf("Riya","Aarav","Vicky","Neha","Rohan","Pooja"))}
@Composable fun SimpleList(title:String,names:List<String>){LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{Text(title,fontSize=25.sp,fontWeight=FontWeight.Bold)};items(names){n->Card(colors=CardDefaults.cardColors(containerColor=Card)){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(44.dp).background(Purple,CircleShape),contentAlignment=Alignment.Center){Text(n.take(1))};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(n,fontWeight=FontWeight.Bold);Text("Online",color=Color(0xFF62E6A5),fontSize=12.sp)};Button(onClick={}){Text("Chat")}}}}}}
@Composable fun Wallet(){Column(Modifier.padding(16.dp)){Text("🪙 My Wallet",fontSize=25.sp,fontWeight=FontWeight.Bold);Card(Modifier.padding(top=14.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFF321064))){Column(Modifier.padding(20.dp)){Text("BALANCE",color=Color.LightGray);Text("12,560 🪙",fontSize=30.sp,fontWeight=FontWeight.Bold);Button(onClick={}){Text("Recharge")}}};Spacer(Modifier.height(12.dp));SimpleCard("Transactions","🎁 Gift from Riya   +300\n💳 Recharge   +10,000\n🎁 Gift to Neha   -500")}}
@Composable fun Vip(){Column(Modifier.padding(16.dp)){Text("👑 VIP Level",fontSize=25.sp,fontWeight=FontWeight.Bold);SimpleCard("VIP 5","6500 / 10000 progress to VIP 6\n\n👑 Daily Coins\n🎁 Special Gifts\n⚔️ PK Priority")}}
@Composable fun Games(){Column(Modifier.padding(16.dp)){Text("🎮 Games",fontSize=25.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(12.dp));LazyVerticalGrid(columns=GridCells.Fixed(2),verticalArrangement=Arrangement.spacedBy(10.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)){listOf("🎲 Ludo","⚔️ Battle Arena","🏎️ Car Race","🧠 Quiz").forEach{item{Card(colors=CardDefaults.cardColors(containerColor=Card)){Box(Modifier.height(120.dp).fillMaxWidth(),contentAlignment=Alignment.Center){Text(it,fontSize=18.sp)}}}}}}}
@Composable fun Rewards(){Column(Modifier.padding(16.dp)){Text("🏆 Rewards & Events",fontSize=25.sp,fontWeight=FontWeight.Bold);SimpleCard("Daily Login","Earn +50 coins");SimpleCard("🎉 Weekend Voice Fest","Join events and win coins.")}}
@Composable fun Profile(){Column(Modifier.padding(16.dp)){Text("👤 Profile",fontSize=25.sp,fontWeight=FontWeight.Bold);SimpleCard("Kabir • ID 12345678","Level 25 🇮🇳\n\n256 Following   •   1.2K Followers   •   35.6K Likes\n\n🪙 12,560 Coins");SimpleCard("My Features","🏠 My Rooms\n👥 Friends\n👑 My Level\n🪙 Wallet\n🏆 Rewards")}}
@Composable fun Settings(){SimpleList("⚙️ Settings",listOf("🔐 Account & Security","🔔 Notifications","🔒 Privacy","🌐 Language","🔊 Sound & Vibration","❓ Help & Support"))}
@Composable fun SimpleCard(t:String,b:String)=Card(Modifier.fillMaxWidth().padding(vertical=6.dp),colors=CardDefaults.cardColors(containerColor=Card)){Column(Modifier.padding(16.dp)){Text(t,fontSize=18.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));Text(b,color=Color.LightGray,lineHeight=22.sp)}}


@Composable fun GiftScreen(back:()->Unit){
 var sent by remember{mutableStateOf("")}
 val gifts=listOf("🌹 Rose" to 10,"❤️ Heart" to 50,"💎 Diamond" to 100,"🍦 Ice Cream" to 200,
  "🚗 Sports Car" to 500,"🛥️ Yacht" to 1000,"🏰 Castle" to 2500,"✈️ Private Jet" to 5000,
  "👑 Crown" to 10000,"🎆 Fireworks" to 25000,"🦄 Unicorn" to 50000,"🌌 Galaxy" to 100000)
 Column(Modifier.fillMaxSize().padding(16.dp)){
  Row(verticalAlignment=Alignment.CenterVertically){Text("‹",fontSize=35.sp,modifier=Modifier.clickable{back()});Spacer(Modifier.width(8.dp));Text("🎁 Gift Center",fontSize=24.sp,fontWeight=FontWeight.Bold)}
  Spacer(Modifier.height(8.dp))
  Card(colors=CardDefaults.cardColors(containerColor=Color(0xFF321064)),shape=RoundedCornerShape(18.dp)){
   Row(Modifier.fillMaxWidth().padding(16.dp),horizontalArrangement=Arrangement.SpaceBetween){
    Column{Text("Your Balance",color=Color.LightGray,fontSize=12.sp);Text("12,560 🪙",fontSize=23.sp,fontWeight=FontWeight.Bold)}
    Button(onClick={}){Text("Recharge")}
   }
  }
  if(sent.isNotEmpty()) Text(sent,color=Color(0xFF62E6A5),modifier=Modifier.padding(vertical=8.dp))
  Text("Choose a gift",fontSize=18.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=8.dp))
  LazyVerticalGrid(columns=GridCells.Fixed(3),verticalArrangement=Arrangement.spacedBy(8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){
   gifts.forEach{(g,c)->item{Card(Modifier.clickable{sent="$g sent successfully! (-$c 🪙)"},colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(15.dp))){
    Column(Modifier.fillMaxWidth().padding(12.dp),horizontalAlignment=Alignment.CenterHorizontally){Text(g.substringBefore(" "),fontSize=34.sp);Text(g.substringAfter(" "),fontSize=12.sp);Text("$c 🪙",color=Gold,fontSize=11.sp,fontWeight=FontWeight.Bold)}
   }}}
  }
 }
}

@Composable fun EmojiScreen(back:()->Unit){
 var selected by remember{mutableStateOf("😀")}
 val emojis=listOf("😀","😂","😍","😘","🥰","😎","😜","🤩","🥳","😇","😱","😢","😡","🤔","👏","👍","🙏","🔥","❤️","💯","🎉","🎊","🌹","💎","👑","✨","🎁","💖","🤣","🙌")
 Column(Modifier.fillMaxSize().padding(16.dp)){
  Row(verticalAlignment=Alignment.CenterVertically){Text("‹",fontSize=35.sp,modifier=Modifier.clickable{back()});Spacer(Modifier.width(8.dp));Text("😀 Emoji Center",fontSize=24.sp,fontWeight=FontWeight.Bold)}
  Card(Modifier.padding(top=12.dp),colors=CardDefaults.cardColors(containerColor=Card),shape=RoundedCornerShape(18.dp)){
   Column(Modifier.fillMaxWidth().padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally){
    Text("Selected",color=Color.Gray);Text(selected,fontSize=65.sp);Text("Tap an emoji to react",color=Color.LightGray)
   }
  }
  Spacer(Modifier.height(12.dp))
  LazyVerticalGrid(columns=GridCells.Fixed(6),verticalArrangement=Arrangement.spacedBy(8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){
   emojis.forEach{e->item{Card(Modifier.clickable{selected=e},colors=CardDefaults.cardColors(containerColor=if(selected==e)Color(0xFF321064) else Card),shape=RoundedCornerShape(12.dp))){Box(Modifier.fillMaxWidth().height(52.dp),contentAlignment=Alignment.Center){Text(e,fontSize=27.sp)}}}}
  }
 }
}

@Composable fun PKBattleScreen(back:()->Unit){
 var time by remember{mutableStateOf(299)}
 val left=12560; val right=8560
 Column(Modifier.fillMaxSize().padding(16.dp)){
  Row(verticalAlignment=Alignment.CenterVertically){Text("‹",fontSize=35.sp,modifier=Modifier.clickable{back()});Spacer(Modifier.width(8.dp));Text("⚔️ PK Battle",fontSize=24.sp,fontWeight=FontWeight.Bold)}
  Card(Modifier.padding(top=12.dp),colors=CardDefaults.cardColors(containerColor=Color(0xFF151027)),shape=RoundedCornerShape(20.dp)){
   Column(Modifier.fillMaxWidth().padding(18.dp)){
    Row(horizontalArrangement=Arrangement.SpaceBetween,modifier=Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){
     Column(horizontalAlignment=Alignment.CenterHorizontally){Box(Modifier.size(70.dp).background(Purple,CircleShape),contentAlignment=Alignment.Center){Text("A",fontSize=30.sp)};Text("Aarav",fontWeight=FontWeight.Bold);Text("$left 🪙",color=Gold)}
     Text("VS",fontSize=25.sp,fontWeight=FontWeight.Black)
     Column(horizontalAlignment=Alignment.CenterHorizontally){Box(Modifier.size(70.dp).background(Color(0xFFB42D6D),CircleShape),contentAlignment=Alignment.Center){Text("R",fontSize=30.sp)};Text("Riya",fontWeight=FontWeight.Bold);Text("$right 🪙",color=Gold)}
    }
    Spacer(Modifier.height(18.dp))
    LinearProgressIndicator(progress={left.toFloat()/(left+right)},modifier=Modifier.fillMaxWidth().height(12.dp),color=Purple,trackColor=Color(0xFF5A254A))
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("64%");Text("04:59");Text("36%")}
   }
  }
  Text("Battle Actions",fontSize=19.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=16.dp,bottom=8.dp))
  Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={}){Text("🎁 Gift")};Button(onClick={}){Text("🔥 Boost")};Button(onClick={}){Text("❤️ Like")}}
  SimpleCard("PK Rules","Send gifts to increase your score. Highest score wins the round.\nLive timer • score sync • winner rewards.")
  Button(onClick={},modifier=Modifier.fillMaxWidth()){Text("JOIN BATTLE")}
 }
}

@Composable fun BottomBar(tab:String,set:(String)->Unit){Row(Modifier.fillMaxWidth().background(Color(0xFF0C0F20)).padding(8.dp),horizontalArrangement=Arrangement.SpaceAround){listOf("Home" to "🏠","Rooms" to "🎙️","Chats" to "💬","Profile" to "👤").forEach{(a,i)->Text("$i\n$a",color=if(tab==a)Color(0xFFC178FF) else Color.Gray,fontSize=11.sp,modifier=Modifier.clickable{set(a)})}}}
