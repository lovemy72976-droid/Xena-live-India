# India Stream Android APK

This is an Android WebView wrapper around the supplied India Stream UI prototype.

## Build

```bash
gradle :app:assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

Push this project to the repository root. The workflow at `.github/workflows/build-apk.yml` builds the debug APK and uploads it as the `India-Stream-APK` artifact.

## Important

The supplied ZIP is a frontend prototype. Voice streaming, real authentication, payments, coin ledger, PK synchronization, notifications, moderation, and a production backend are not implemented in this package.
