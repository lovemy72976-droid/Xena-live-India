# Xena Live India — Working Source Package

This ZIP contains the screenshot-inspired mobile app, the generated visual assets,
and the connected API server.

## Included

- `artifacts/xena-live-india` — Expo mobile app
- `artifacts/api-server` — Express API for accounts, rooms, chat, follows, gifts, and wallet
- `lib/api-spec` — API contract used by the shared client
- Generated room host graphics in `artifacts/xena-live-india/assets/images`

## Run

Use pnpm from the project root:

```bash
pnpm --filter @workspace/api-server run dev
pnpm --filter @workspace/xena-live-india run dev
```

The mobile app uses `EXPO_PUBLIC_DOMAIN` to reach the API server. Do not put
passwords, tokens, or production secrets inside the ZIP.

## Current scope

Login, signup, server persistence, live room creation, chat, follow/unfollow,
gifts, wallet, profile, and logout are connected. Actual camera-to-viewer
broadcasting is not included in this package.