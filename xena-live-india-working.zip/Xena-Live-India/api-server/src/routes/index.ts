import { Router, type IRouter } from "express";
import healthRouter from "./health";
import xenaRouter from "./xena";

const router: IRouter = Router();

router.use(healthRouter);
router.use(xenaRouter);

export default router;
