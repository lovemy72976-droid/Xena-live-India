import { Router, type IRouter, type Request, type Response, type NextFunction } from "express";
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

type User = { id: string; username: string; password: string; coins: number; diamonds: number; followers: number; following: number };
type Room = { id: string; hostId: string; hostName: string; title: string; category: string; status: "live" | "ended"; viewerCount: number; createdAt: string };
type Message = { id: string; roomId: string; userId: string; username: string; text: string; createdAt: string };
type Store = { users: User[]; rooms: Room[]; messages: Message[]; follows: string[]; transactions: Array<Record<string, unknown>> };

const router: IRouter = Router();
const dataFile = process.env.XENA_DATA_FILE ?? path.join(process.cwd(), "data", "xena.json");
const secret = process.env.SESSION_SECRET ?? "xena-development-session-secret";
fs.mkdirSync(path.dirname(dataFile), { recursive: true });
const emptyStore = (): Store => ({ users: [], rooms: [], messages: [], follows: [], transactions: [] });
let store: Store = (() => {
  try { return JSON.parse(fs.readFileSync(dataFile, "utf8")) as Store; } catch { return emptyStore(); }
})();
const save = () => fs.writeFileSync(dataFile, JSON.stringify(store, null, 2));
const id = (prefix: string) => `${prefix}_${Date.now().toString(36)}_${crypto.randomBytes(4).toString("hex")}`;
const publicUser = (u: User) => ({ id: u.id, username: u.username, coins: u.coins, diamonds: u.diamonds, followers: u.followers, following: u.following });
const sign = (userId: string) => {
  const body = Buffer.from(JSON.stringify({ userId, exp: Date.now() + 30 * 24 * 60 * 60 * 1000 })).toString("base64url");
  return `${body}.${crypto.createHmac("sha256", secret).update(body).digest("base64url")}`;
};
const readToken = (token: string | undefined) => {
  if (!token) return null;
  const [body, signature] = token.split(".");
  if (!body || !signature) return null;
  const expected = crypto.createHmac("sha256", secret).update(body).digest("base64url");
  if (signature.length !== expected.length || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) return null;
  try { const payload = JSON.parse(Buffer.from(body, "base64url").toString()) as { userId: string; exp: number }; return payload.exp > Date.now() ? payload.userId : null; } catch { return null; }
};
const auth = (req: Request, res: Response, next: NextFunction) => {
  const userId = readToken(req.headers.authorization?.replace(/^Bearer /, ""));
  if (!userId || !store.users.some((u) => u.id === userId)) return res.status(401).json({ error: "Login required" });
  res.locals.userId = userId;
  return next();
};

router.post("/auth/signup", (req, res) => {
  const username = String(req.body?.username ?? "").trim();
  const password = String(req.body?.password ?? "");
  if (username.length < 3 || password.length < 6) return res.status(400).json({ error: "Username must be 3+ characters and password 6+ characters" });
  if (store.users.some((u) => u.username.toLowerCase() === username.toLowerCase())) return res.status(409).json({ error: "Username already exists" });
  const user: User = { id: id("u"), username, password: crypto.createHash("sha256").update(password).digest("hex"), coins: 1200, diamonds: 0, followers: 0, following: 0 };
  store.users.push(user); save(); return res.json({ token: sign(user.id), user: publicUser(user) });
});
router.post("/auth/login", (req, res) => {
  const username = String(req.body?.username ?? "").trim();
  const password = String(req.body?.password ?? "");
  const user = store.users.find((u) => u.username.toLowerCase() === username.toLowerCase());
  if (!user || user.password !== crypto.createHash("sha256").update(password).digest("hex")) return res.status(401).json({ error: "Incorrect username or password" });
  return res.json({ token: sign(user.id), user: publicUser(user) });
});
router.get("/me", auth, (_req, res) => {
  const user = store.users.find((u) => u.id === res.locals.userId)!;
  res.json(publicUser(user));
});
router.get("/rooms", auth, (_req, res) => res.json({ rooms: store.rooms.filter((r) => r.status === "live").sort((a, b) => b.createdAt.localeCompare(a.createdAt)) }));
router.post("/rooms", auth, (req, res) => {
  const title = String(req.body?.title ?? "").trim();
  const category = String(req.body?.category ?? "General").trim();
  if (!title) return res.status(400).json({ error: "A room title is required" });
  const user = store.users.find((u) => u.id === res.locals.userId)!;
  const room: Room = { id: id("room"), hostId: user.id, hostName: user.username, title, category, status: "live", viewerCount: 0, createdAt: new Date().toISOString() };
  store.rooms.push(room); save(); return res.json(room);
});
router.get("/rooms/:roomId/messages", auth, (req, res) => res.json({ messages: store.messages.filter((m) => m.roomId === req.params.roomId).slice(-100) }));
router.post("/rooms/:roomId/messages", auth, (req, res) => {
  const text = String(req.body?.text ?? "").trim();
  if (!text || text.length > 500) return res.status(400).json({ error: "Message must be 1–500 characters" });
  const room = store.rooms.find((r) => r.id === req.params.roomId && r.status === "live");
  if (!room) return res.status(404).json({ error: "Room is not live" });
  const user = store.users.find((u) => u.id === res.locals.userId)!;
  const message: Message = { id: id("msg"), roomId: room.id, userId: user.id, username: user.username, text, createdAt: new Date().toISOString() };
  store.messages.push(message); save(); return res.json(message);
});
router.post("/users/:userId/follow", auth, (req, res) => {
  const key = `${res.locals.userId}:${req.params.userId}`;
  const existing = store.follows.indexOf(key);
  if (existing >= 0) store.follows.splice(existing, 1); else store.follows.push(key);
  const target = store.users.find((u) => u.id === req.params.userId);
  if (target) target.followers = store.follows.filter((f) => f.endsWith(`:${target.id}`)).length;
  const me = store.users.find((u) => u.id === res.locals.userId)!;
  me.following = store.follows.filter((f) => f.startsWith(`${me.id}:`)).length;
  save(); return res.json({ following: existing < 0 });
});
router.get("/wallet", auth, (_req, res) => {
  const user = store.users.find((u) => u.id === res.locals.userId)!;
  res.json({ coins: user.coins, diamonds: user.diamonds });
});
router.post("/gifts", auth, (req, res) => {
  const coins = Math.max(1, Math.floor(Number(req.body?.coins)));
  const sender = store.users.find((u) => u.id === res.locals.userId);
  const receiver = store.users.find((u) => u.id === String(req.body?.receiverId));
  if (!sender || !receiver) return res.status(404).json({ error: "User not found" });
  if (sender.coins < coins) return res.status(400).json({ error: "Not enough coins" });
  sender.coins -= coins; receiver.diamonds += Math.max(1, Math.floor(coins / 10));
  store.transactions.push({ id: id("tx"), from: sender.id, to: receiver.id, coins, createdAt: new Date().toISOString() });
  save(); return res.json({ coins: sender.coins, diamonds: sender.diamonds });
});

export default router;