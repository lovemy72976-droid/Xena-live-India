CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE TABLE IF NOT EXISTS users (
 id text PRIMARY KEY, mobile text UNIQUE, username text UNIQUE NOT NULL, email text UNIQUE,
 password_hash text, oauth_provider text, oauth_id text, coins bigint NOT NULL DEFAULT 0,
 diamonds bigint NOT NULL DEFAULT 0, followers bigint NOT NULL DEFAULT 0, following bigint NOT NULL DEFAULT 0,
 likes bigint NOT NULL DEFAULT 0, is_admin boolean NOT NULL DEFAULT false, is_banned boolean NOT NULL DEFAULT false,
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS users_oauth_unique ON users(oauth_provider,oauth_id) WHERE oauth_provider IS NOT NULL AND oauth_id IS NOT NULL;
CREATE TABLE IF NOT EXISTS rooms (
 id text PRIMARY KEY, host_id text NOT NULL REFERENCES users(id) ON DELETE CASCADE, host_name text NOT NULL,
 title text NOT NULL, category text NOT NULL, status text NOT NULL, viewer_count bigint NOT NULL DEFAULT 0,
 created_at timestamptz NOT NULL DEFAULT now(), ended_at timestamptz
);
CREATE TABLE IF NOT EXISTS messages (
 id text PRIMARY KEY, room_id text NOT NULL REFERENCES rooms(id) ON DELETE CASCADE, user_id text NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 username text NOT NULL, text text NOT NULL, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS transactions (
 id text PRIMARY KEY, user_id text NOT NULL REFERENCES users(id) ON DELETE CASCADE, type text NOT NULL,
 amount bigint NOT NULL, room_id text, receiver_id text, sender_id text, description text,
 purchase_token text UNIQUE, product_id text, created_at timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS follows (from_user text NOT NULL REFERENCES users(id) ON DELETE CASCADE, to_user text NOT NULL REFERENCES users(id) ON DELETE CASCADE, created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(from_user,to_user));
CREATE TABLE IF NOT EXISTS blocks (from_user text NOT NULL REFERENCES users(id) ON DELETE CASCADE, to_user text NOT NULL REFERENCES users(id) ON DELETE CASCADE, created_at timestamptz NOT NULL DEFAULT now(), PRIMARY KEY(from_user,to_user));
CREATE TABLE IF NOT EXISTS reports (
 id text PRIMARY KEY, reporter_id text NOT NULL REFERENCES users(id) ON DELETE CASCADE, target_user_id text REFERENCES users(id) ON DELETE SET NULL,
 room_id text REFERENCES rooms(id) ON DELETE SET NULL, message_id text, reason text NOT NULL, status text NOT NULL DEFAULT 'open',
 moderator_note text, created_at timestamptz NOT NULL DEFAULT now(), resolved_at timestamptz
);
CREATE INDEX IF NOT EXISTS idx_rooms_status ON rooms(status,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_room ON messages(room_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reports_status ON reports(status,created_at DESC);
