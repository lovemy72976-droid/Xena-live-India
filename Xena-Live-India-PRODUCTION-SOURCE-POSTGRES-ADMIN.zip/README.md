# Xena Live India — Full Source Package v4.0

This package contains the Android client and the Node.js real-time backend.

## Included
- HTTPS-ready Node.js/Express server
- JWT authentication with bcrypt password hashing
- Automatic first-boot JWT secret when no secret is supplied
- Socket.IO live-room presence and chat
- WebRTC camera/microphone live streaming with STUN/TURN configuration
- Follow, gift, block, report and account deletion APIs
- Google/Facebook OAuth integration hooks
- Google Play purchase verification endpoint
- Privacy, Terms, Community Guidelines and Delete Account pages
- Render/Koyeb deployment files
- Android client with Play Billing integration

## Koyeb
Use the root `Dockerfile`. The app listens on `PORT` (defaults to 8080) and exposes `/health` and `/app`.

For testing, no JWT secret is required: the server creates a random one in `data/.jwt-secret`.
For production, set a Koyeb Secret named `JWT_SECRET` with at least 32 random characters.

## Data warning
The default JSON store is a zero-setup test store. Koyeb local filesystem data is ephemeral. For real users, connect a persistent database or attach persistent storage. Do not use the JSON fallback for real payments or a large production audience.

## Play Store warning
A ZIP cannot safely contain your private Play service-account key, OAuth secrets, database password or Android release signing key. Those must be created in your own accounts and supplied as secrets/configuration.

See `KOYEB_DEPLOY.md`, `DEPLOYMENT_REQUIRED_BEFORE_REAL_USERS.md` and `PLAY_STORE_CHECKLIST.md`.
