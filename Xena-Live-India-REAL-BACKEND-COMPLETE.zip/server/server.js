const express = require('express');
const http = require('http');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { Server } = require('socket.io');

const PORT = process.env.PORT || 8080;
const JWT_SECRET = process.env.JWT_SECRET || 'CHANGE_THIS_SECRET_IN_PRODUCTION';
const DB_FILE = process.env.DATA_FILE || path.join(__dirname, 'data.json');

function loadDb(){
  if(!fs.existsSync(DB_FILE)) return {users:[], rooms:[], messages:[], transactions:[], follows:[]};
  try { return JSON.parse(fs.readFileSync(DB_FILE,'utf8')); } catch { return {users:[],rooms:[],messages:[],transactions:[],follows:[]}; }
}
let db = loadDb();
function saveDb(){ fs.writeFileSync(DB_FILE, JSON.stringify(db,null,2)); }
function id(prefix){ return prefix + '_' + Math.random().toString(36).slice(2,10) + Date.now().toString(36); }
function safeUser(u){ return {id:u.id,username:u.username,mobile:u.mobile,coins:u.coins,diamonds:u.diamonds,followers:u.followers,following:u.following,likes:u.likes}; }
function tokenFor(u){ return jwt.sign({id:u.id}, JWT_SECRET, {expiresIn:'30d'}); }
function auth(req,res,next){
  const h=req.headers.authorization||''; if(!h.startsWith('Bearer ')) return res.status(401).json({error:'Login required'});
  try { req.user=jwt.verify(h.slice(7),JWT_SECRET); next(); } catch { res.status(401).json({error:'Invalid or expired token'}); }
}
function findUser(id){ return db.users.find(u=>u.id===id); }
function publicRoom(r){ return {...r, viewerCount:r.viewerCount||0}; }

const app=express();
app.use(cors({origin:true,credentials:true}));
app.use(express.json({limit:'1mb'}));
app.get('/health',(req,res)=>res.json({ok:true,name:'Xena Live India',time:new Date().toISOString()}));
app.use(express.static(path.join(__dirname,'public')));
app.get('/app',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));

app.post('/api/auth/signup',async(req,res)=>{
  const {mobile,username,password}=req.body||{};
  if(!mobile||!username||!password) return res.status(400).json({error:'Mobile, username and password are required'});
  if(password.length<6) return res.status(400).json({error:'Password must be at least 6 characters'});
  if(db.users.some(u=>u.mobile===mobile||u.username.toLowerCase()===username.toLowerCase())) return res.status(409).json({error:'Mobile or username already exists'});
  const u={id:id('u'),mobile,username,passwordHash:await bcrypt.hash(password,10),coins:12050,diamonds:560,followers:0,following:0,likes:0,createdAt:Date.now()};
  db.users.push(u); saveDb(); res.json({token:tokenFor(u),user:safeUser(u)});
});
app.post('/api/auth/login',async(req,res)=>{
  const {mobile,password}=req.body||{}; const u=db.users.find(x=>x.mobile===mobile);
  if(!u || !(await bcrypt.compare(password||'',u.passwordHash))) return res.status(401).json({error:'Invalid mobile or password'});
  res.json({token:tokenFor(u),user:safeUser(u)});
});
app.get('/api/me',auth,(req,res)=>{const u=findUser(req.user.id); if(!u)return res.status(404).json({error:'User not found'}); res.json({user:safeUser(u)});});

app.get('/api/rooms',auth,(req,res)=>res.json({rooms:db.rooms.filter(r=>r.status==='live').map(publicRoom)}));
app.post('/api/rooms',auth,(req,res)=>{
  const {title='My Live Stream',category='Music'}=req.body||{};
  db.rooms.filter(r=>r.hostId===req.user.id && r.status==='live').forEach(r=>r.status='ended');
  const u=findUser(req.user.id); const room={id:id('room'),hostId:u.id,hostName:u.username,title,category,status:'live',viewerCount:0,createdAt:Date.now()};
  db.rooms.push(room); saveDb(); res.json({room:publicRoom(room)});
});
app.post('/api/rooms/:roomId/end',auth,(req,res)=>{const r=db.rooms.find(x=>x.id===req.params.roomId&&x.hostId===req.user.id);if(!r)return res.status(404).json({error:'Room not found'});r.status='ended';saveDb();res.json({ok:true});});

app.get('/api/rooms/:roomId/messages',auth,(req,res)=>{
  res.json({messages:db.messages.filter(m=>m.roomId===req.params.roomId).slice(-100)});
});
app.post('/api/rooms/:roomId/messages',auth,(req,res)=>{
  const u=findUser(req.user.id); const text=String(req.body?.text||'').trim();
  if(!text)return res.status(400).json({error:'Message required'});
  const m={id:id('msg'),roomId:req.params.roomId,userId:u.id,username:u.username,text:text.slice(0,500),createdAt:Date.now()};
  db.messages.push(m); if(db.messages.length>5000)db.messages=db.messages.slice(-5000); saveDb(); io.to(req.params.roomId).emit('chat:message',m); res.json({message:m});
});

app.post('/api/users/:userId/follow',auth,(req,res)=>{
  const me=findUser(req.user.id), target=findUser(req.params.userId); if(!target)return res.status(404).json({error:'User not found'}); if(me.id===target.id)return res.status(400).json({error:'Cannot follow yourself'});
  const exists=db.follows.some(f=>f.from===me.id&&f.to===target.id); if(exists){db.follows=db.follows.filter(f=>!(f.from===me.id&&f.to===target.id));target.followers=Math.max(0,target.followers-1);me.following=Math.max(0,me.following-1);}else{db.follows.push({from:me.id,to:target.id});target.followers++;me.following++;} saveDb(); res.json({following:!exists,user:safeUser(target)});
});

app.get('/api/wallet',auth,(req,res)=>{const u=findUser(req.user.id);res.json({coins:u.coins,diamonds:u.diamonds,transactions:db.transactions.filter(t=>t.userId===u.id).slice(-100).reverse()});});
app.post('/api/gifts',auth,(req,res)=>{
  const {roomId,receiverId,coins=100,gift='🎁'}=req.body||{}; const amount=Math.max(1,Math.floor(Number(coins)));
  const sender=findUser(req.user.id), receiver=findUser(receiverId); if(!receiver)return res.status(404).json({error:'Receiver not found'});
  if(sender.coins<amount)return res.status(400).json({error:'Not enough coins'});
  sender.coins-=amount; receiver.diamonds+=Math.max(1,Math.floor(amount/10));
  const tx={id:id('tx'),userId:sender.id,type:'gift_sent',amount:-amount,roomId,receiverId,createdAt:Date.now(),description:`${gift} gift sent`};
  db.transactions.push(tx); db.transactions.push({id:id('tx'),userId:receiver.id,type:'gift_received',amount:Math.max(1,Math.floor(amount/10)),roomId,senderId:sender.id,createdAt:Date.now(),description:`${gift} gift received`}); saveDb();
  io.to(roomId).emit('gift:sent',{from:sender.username,to:receiver.username,gift,coins:amount}); res.json({ok:true,coins:sender.coins,diamonds:receiver.diamonds});
});

const server=http.createServer(app); const io=new Server(server,{cors:{origin:true,credentials:true}});
const sockets=new Map();
io.use((socket,next)=>{try{const t=socket.handshake.auth?.token;socket.user=jwt.verify(t,JWT_SECRET);next();}catch{next(new Error('Unauthorized'));}});
io.on('connection',socket=>{
  sockets.set(socket.id,socket); socket.on('room:join',({roomId})=>{
    const r=db.rooms.find(x=>x.id===roomId&&x.status==='live'); if(!r)return socket.emit('room:error','Room is not live');
    socket.join(roomId); socket.data.roomId=roomId; socket.data.role=socket.user.id===r.hostId?'host':'viewer';
    r.viewerCount=(r.viewerCount||0)+1; saveDb(); io.to(roomId).emit('room:count',{count:r.viewerCount});
    if(socket.data.role==='viewer') io.to(r.id).emit('webrtc:viewer-joined',{viewerId:socket.id});
  });
  socket.on('room:leave',()=>leave(socket));
  socket.on('chat:message',({roomId,text})=>{
    const r=db.rooms.find(x=>x.id===roomId&&x.status==='live'); if(!r)return; const u=findUser(socket.user.id); if(!u)return;
    const m={id:id('msg'),roomId,userId:u.id,username:u.username,text:String(text||'').trim().slice(0,500),createdAt:Date.now()}; if(!m.text)return;
    db.messages.push(m); saveDb(); io.to(roomId).emit('chat:message',m);
  });
  socket.on('webrtc:offer',({viewerId,offer})=>io.to(viewerId).emit('webrtc:offer',{hostId:socket.id,offer}));
  socket.on('webrtc:answer',({hostId,answer})=>io.to(hostId).emit('webrtc:answer',{viewerId:socket.id,answer}));
  socket.on('webrtc:candidate',({targetId,candidate})=>io.to(targetId).emit('webrtc:candidate',{fromId:socket.id,candidate}));
  socket.on('disconnect',()=>leave(socket));
});
function leave(socket){const roomId=socket.data.roomId;if(!roomId)return;const r=db.rooms.find(x=>x.id===roomId);if(r){r.viewerCount=Math.max(0,(r.viewerCount||1)-1);if(socket.data.role==='host')r.status='ended';saveDb();io.to(roomId).emit('room:count',{count:r.viewerCount});}socket.data.roomId=null;}
server.listen(PORT,()=>console.log(`Xena Live server listening on ${PORT}`));
