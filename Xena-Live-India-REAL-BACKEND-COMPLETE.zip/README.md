# Xena Live India — Real-time backend build

This project contains the Android shell plus a Node.js backend for real-time login, rooms, chat, gifts/coins and WebRTC live video/audio.

## What is real now
- Server-side signup/login with bcrypt + JWT.
- Live-room creation and room list.
- Socket.IO real-time room presence and chat.
- WebRTC host camera + microphone to viewers.
- Server-side coin/diamond ledger and gift transaction checks.
- Follow/unfollow stored on the server.
- Android WebView requests camera/microphone permissions.
- HTTPS server URL is injected into the APK at build time.

## Important production requirement
The APK cannot invent a public server. Deploy the `server/` directory to a Node.js HTTPS host first. Then set the GitHub repository variable `XENA_SERVER_URL` to the exact HTTPS URL ending in `/app`, for example `https://your-domain.example/app`.

The included `render.yaml` can be used to deploy the Node service on Render. For persistent production user data, use a persistent database/storage rather than the default JSON file. The current JSON store is suitable for testing/demo deployments and will reset on hosts with ephemeral filesystems.

## Build on GitHub
1. Deploy `server/` and copy its HTTPS `/app` URL.
2. In GitHub: Settings → Secrets and variables → Actions → Variables → New repository variable.
3. Name: `XENA_SERVER_URL`.
4. Value: your HTTPS `/app` URL.
5. Run the `Build Android APK` workflow.
6. Download `Xena-Live-India-debug-APK` from the workflow artifacts.

## WebRTC note
The project uses WebRTC with public Google STUN servers. For reliable production streaming across restrictive mobile networks, add a TURN server and replace/add its ICE configuration in `server/public/index.html`. A media server such as LiveKit is recommended for large rooms because browser-to-browser mesh does not scale to many viewers.

## Real-money top-ups
Coins/gifts are server controlled, but this package does not pretend to process real money. To sell coins for INR, connect a payment provider (for example Razorpay) and credit coins only from a verified server-side payment webhook. Never credit coins from Android/JavaScript alone.
