# Render deployment fix

This package includes a **root-level `render.yaml`**. Render Blueprints normally look
for `render.yaml` in the repository root. The backend itself remains under `server/`
and uses `rootDir: server`.

The Blueprint provisions:
- Node web service
- PostgreSQL database
- `DATABASE_URL` wired automatically from PostgreSQL
- generated `JWT_SECRET`
- `/health` health check

After creating/syncing the Blueprint, fill the secret values marked `sync: false`
in Render. Do not commit passwords, private keys, or service-account JSON to Git.

The server now prints a clear startup error if `DATABASE_URL` or `JWT_SECRET` is
missing, instead of only showing `Exited with status 1`.

For a real Play Store launch, use a paid/stable database and web-service plan,
configure a TURN server for reliable WebRTC, configure Play Billing verification,
and test the signed Android App Bundle on multiple real devices before production.
