# Xena Live India — production validation

This package contains no seeded users, fake rooms, fake chats, fake wallet balances, or JSON user datastore. PostgreSQL is the system of record.

Before release, configure a real HTTPS server URL, PostgreSQL, TURN credentials, Google Play Billing products/service account, admin credentials, support email, and Android signing key.

## Required checks

1. `GET /health` returns `ok: true` and `database: postgresql`.
2. Sign up two test accounts; verify they persist after a server restart.
3. Login/logout and account deletion work.
4. Create a live room from one device and join it from another network.
5. Verify camera/microphone, WebRTC media, TURN fallback, viewer counts, live chat, follow, block and report.
6. Verify direct chats between two accounts.
7. Verify Google Play purchase server-side and confirm duplicate purchase tokens cannot credit twice.
8. Verify admin login, user moderation, reports and transaction review.
9. Test HTTPS, rate limits, CORS, backup/restore and database migrations.
10. Build a signed AAB with the final package ID and upload it to Play Console internal testing before production.

The repository cannot contain your private database password, Play service-account JSON, TURN secret, OAuth secret, or release keystore. Those must be configured in the deployment/CI secret store.
