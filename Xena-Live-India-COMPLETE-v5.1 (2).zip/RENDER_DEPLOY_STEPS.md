# Xena Live India — Render + PostgreSQL deploy (step-by-step)

Yeh package **real PostgreSQL** use karta hai (JSON store nahi). Render par deploy:

## 1. Render account
1. https://render.com par account banao / login karo.
2. GitHub par is project ko push karo (ya ZIP se new repo).

## 2. Blueprint se deploy (recommended)
1. Render Dashboard → **New** → **Blueprint**
2. Apna GitHub repo select karo
3. Root par `render.yaml` already hai — ye automatically:
   - Web service `xena-live-india` (Node)
   - PostgreSQL database `xena-live-db`
   - `DATABASE_URL` + random `JWT_SECRET` set karega

## 3. Environment variables (manually set karo)
Render → Service → Environment:

| Key | Value |
|-----|--------|
| `ADMIN_EMAIL` | aapka admin email (e.g. admin@xenalive.in) |
| `ADMIN_PASSWORD` | strong password (min 12 chars) |
| `SUPPORT_EMAIL` | support@xenalive.in |
| `CORS_ORIGINS` | `https://YOUR-APP.onrender.com` (comma-separated if multiple) |
| `NODE_ENV` | `production` |
| `ANDROID_PACKAGE_NAME` | `com.xenalive.india` |

Optional (later):
- `TURN_URL`, `TURN_USERNAME`, `TURN_CREDENTIAL` — mobile WebRTC ke liye (Metered.ca / Twilio)
- `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_REDIRECT_URI`
- `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` — Play Billing verify ke liye full JSON string

## 4. Deploy ke baad verify
1. `https://YOUR-APP.onrender.com/health` → `{"ok":true,"database":"postgresql",...}`
2. App: `https://YOUR-APP.onrender.com/app`
3. Admin: `https://YOUR-APP.onrender.com/admin`  
   Login: `ADMIN_EMAIL` + `ADMIN_PASSWORD`

## 5. Android client
`app/src/main/java/.../MainActivity.java` / assets mein API base URL ko apne Render URL se set karo  
(ya index.html ke config section mein `API_BASE`).

Phir signed AAB banao (Play Console).

## 6. Important
- Free Render web service sleep ho sakta hai — production ke liye paid plan better.
- Database backups Render dashboard se enable karo.
- Kabhi bhi real users se pehle `PRODUCTION_VALIDATION.md` checklist complete karo.
