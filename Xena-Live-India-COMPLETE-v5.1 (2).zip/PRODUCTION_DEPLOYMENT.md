# Xena Live India — production deployment

This package removes the JSON datastore and uses PostgreSQL as the system of record. It also adds a protected admin panel at `/admin`.

## Required before real users
1. Create a managed PostgreSQL database and put its `DATABASE_URL` in `server/.env`.
2. Set a random `JWT_SECRET` of at least 32 characters.
3. Set `ADMIN_EMAIL` and `ADMIN_PASSWORD` once for the initial administrator. Change the admin password after first login and rotate secrets.
4. Put the public HTTPS origin in `CORS_ORIGINS`.
5. Configure a real TURN service for mobile WebRTC reliability. The included STUN server alone is not sufficient for all networks.
6. Configure Google Play products and `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` for server-side purchase verification.
7. Build a signed Android App Bundle (AAB), not just an unsigned/debug APK.
8. Run two-device tests for signup/login, camera/mic permissions, live streaming, chat, report/block, account deletion and billing before production.

## Important
The repository cannot contain your database password, Play service-account key, OAuth secrets or release signing key. Those must be supplied as deployment secrets.

## Admin
Open `https://<your-deployed-host>/admin`, sign in with `ADMIN_EMAIL`/`ADMIN_PASSWORD`, then change the password/credentials using your deployment secret process. The panel supports user moderation, reports and transaction review.

## Scaling
The included Socket.IO/WebRTC room implementation is suitable for a single application instance. For a large public audience, use a production SFU/media service and a shared Socket.IO adapter/Redis before horizontal scaling.
