package com.xenalive.india;

import android.app.Activity;
import android.webkit.WebView;
import com.android.billingclient.api.*;
import java.util.*;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;

public class BillingManager implements PurchasesUpdatedListener {
    private final Activity activity; private final WebView webView; private BillingClient billing; private String authToken="";
    private static final Map<String,String> PRODUCTS = new HashMap<>();
    static { PRODUCTS.put("coins_100", "100"); PRODUCTS.put("coins_500", "500"); PRODUCTS.put("coins_1000", "1000"); PRODUCTS.put("coins_5000", "5000"); }
    public BillingManager(Activity a, WebView w){activity=a;webView=w;}
    public void start(){
        PendingPurchasesParams pending=PendingPurchasesParams.newBuilder().enableOneTimeProducts().build();
        billing=BillingClient.newBuilder(activity).setListener(this).enablePendingPurchases(pending).enableAutoServiceReconnection().build();
        billing.startConnection(new BillingClientStateListener(){public void onBillingSetupFinished(BillingResult r){ if(r.getResponseCode()==BillingClient.BillingResponseCode.OK) queryProducts(); }
            public void onBillingServiceDisconnected(){}});
    }
    private void queryProducts(){
        List<QueryProductDetailsParams.Product> ps=new ArrayList<>();
        for(String id:PRODUCTS.keySet()) ps.add(QueryProductDetailsParams.Product.newBuilder().setProductId(id).setProductType(BillingClient.ProductType.INAPP).build());
        billing.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(ps).build(), (r,res)->{});
    }
    public void buy(String productId, String token){ authToken=token;
        if(!PRODUCTS.containsKey(productId)){notifyJs("billingError","Unknown product");return;}
        QueryProductDetailsParams.Product q=QueryProductDetailsParams.Product.newBuilder().setProductId(productId).setProductType(BillingClient.ProductType.INAPP).build();
        billing.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(Collections.singletonList(q)).build(), (r,res)->{
            if(r.getResponseCode()!=BillingClient.BillingResponseCode.OK || res.getProductDetailsList().isEmpty()){notifyJs("billingError","Product unavailable");return;}
            ProductDetails pd=res.getProductDetailsList().get(0);
            ProductDetails.OneTimePurchaseOfferDetails offer=pd.getOneTimePurchaseOfferDetails();
            if(offer==null){notifyJs("billingError","No purchase offer");return;}
            BillingFlowParams bp=BillingFlowParams.newBuilder().setProductDetailsParamsList(Collections.singletonList(BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd).setOfferToken(offer.getOfferToken()).build())).build();
            billing.launchBillingFlow(activity,bp);
        });
    }
    @Override public void onPurchasesUpdated(BillingResult r,List<Purchase> purchases){
        if(r.getResponseCode()!=BillingClient.BillingResponseCode.OK || purchases==null)return;
        for(Purchase p:purchases){ if(p.getPurchaseState()==Purchase.PurchaseState.PURCHASED){ String product=p.getProducts().isEmpty()?"":p.getProducts().get(0); verifyOnServer(product,p.getPurchaseToken()); } }
    }
    private void verifyOnServer(String product,String token){ new Thread(()->{ try{
        URL u=new URL(BuildConfig.SERVER_URL+"/api/billing/verify"); HttpURLConnection c=(HttpURLConnection)u.openConnection(); c.setRequestMethod("POST"); c.setRequestProperty("Content-Type","application/json"); c.setRequestProperty("Authorization","Bearer "+authToken); c.setDoOutput(true);
        JSONObject o=new JSONObject(); o.put("productId",product); o.put("purchaseToken",token); String js="window.onNativePurchase("+JSONObject.quote(o.toString())+")";
        activity.runOnUiThread(()->webView.evaluateJavascript(js,null)); c.disconnect();
      }catch(Exception e){ activity.runOnUiThread(()->notifyJs("billingError","Purchase verification could not start")); }}).start(); }
    private void notifyJs(String event,String msg){webView.post(()->webView.evaluateJavascript("window."+event+"("+JSONObject.quote(msg)+")",null));}
}
