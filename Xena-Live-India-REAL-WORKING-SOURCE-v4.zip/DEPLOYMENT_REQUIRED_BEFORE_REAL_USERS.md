# Xena Live India — Required production configuration

The source package contains the Android client and Node.js backend. Before real users can use it:

1. Deploy `server/` to an HTTPS Node.js service.
2. Set a strong `JWT_SECRET`.
3. Use persistent production storage/database; the bundled JSON storage is for testing/small deployments.
4. Configure TURN (`TURN_URL`, `TURN_USERNAME`, `TURN_CREDENTIAL`) for mobile WebRTC reliability.
5. Configure Google OAuth callback and credentials.
6. Configure Facebook OAuth callback and credentials.
7. Create the Play Billing products and Google Play Developer API service account.
8. Set `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` on the server only.
9. Set the Android `SERVER_URL`/GitHub variable to the exact production `/app` URL.
10. Create a release signing key and build the signed AAB.
11. Test with two real Android devices: signup/login, room creation/join, camera/mic, chat, gift, purchase verification, block/report and account deletion.
