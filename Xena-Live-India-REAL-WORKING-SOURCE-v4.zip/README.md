# Xena Live India — Play Store Complete Release Package

This is the production-preparation package for Xena Live India. It contains the Android app, Node.js real-time backend, legal pages, moderation endpoints and a Play Store release workflow.

## Real features included
- Server signup/login with bcrypt + JWT.
- Real users and live-room state.
- Socket.IO room presence and chat.
- WebRTC camera + microphone streaming with configurable STUN/TURN.
- Follow/unfollow.
- Server-controlled coins, diamonds and gifts.
- Google Play Billing Library 9.1.0 client and server purchase verification endpoint.
- Report/block and account deletion.
- Privacy policy, terms, community guidelines and account-deletion page.
- Android target API 36 and release AAB workflow.

## Important
This repository is **code-complete for deployment preparation**, but no software package can create your Google Play developer account, domain, TURN service, payment products, signing identity or Google service-account permissions for you. Those are account/credential steps that must be completed by the owner.

For the exact remaining launch steps see `PLAY_STORE_CHECKLIST.md`.


## Google / Facebook Login
The app now includes real Google and Facebook OAuth buttons. Configure these server environment variables before use: `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_REDIRECT_URI`, `FACEBOOK_APP_ID`, `FACEBOOK_APP_SECRET`, `FACEBOOK_REDIRECT_URI`. Register the exact callback URLs shown in `.env.example`. The Android app returns to the `xena://oauth` deep link and stores the server JWT.


## v4 fixes included
- Android wallet now reads coins/diamonds/transactions from the server instead of showing hard-coded demo balances.
- Google Play Billing buttons now invoke the Android Billing client and only show success after server-side purchase verification responds successfully.
- WebRTC now consumes `/api/config`, so configured TURN servers are used instead of STUN-only hard-coding.
- Removed explicit demo wording from settings/support actions.

## Important
This is a real source/integration package, not a magically pre-configured production deployment. A production launch still requires the owner's HTTPS server, persistent production database/storage, TURN credentials, Google/Meta OAuth credentials, Google Play Billing products/service-account permissions, and release signing key.
