# Keep this file for future release shrinking rules.
