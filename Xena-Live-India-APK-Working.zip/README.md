# Xena Live India - APK Build Project

This is a **root-level Android Gradle project** prepared for GitHub Actions.

## Important
The project is intentionally NOT stored inside another folder and the web app is stored at:

`app/src/main/assets/index.html`

The GitHub workflow builds directly with Gradle 8.9. It does **not** extract a ZIP and does not search for a project, which avoids the previous `Gradle project not found` error.

## GitHub
Upload the **contents of this ZIP** to the root of your repository so these files are visible at the repository root:

- `settings.gradle`
- `build.gradle`
- `gradle.properties`
- `app/`
- `.github/workflows/build-apk.yml`

Then open **Actions -> Build Android APK**. A successful run will create an artifact named `Xena-Live-India-debug-APK`.
